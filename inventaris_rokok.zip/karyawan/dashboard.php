<?php 
session_start();
// KODE PENGAMAN: Hanya karyawan yang boleh masuk
if($_SESSION['role'] != "karyawan"){
    header("location:../index.php?pesan=bukan_karyawan");
    exit();
}
include '../config/koneksi.php';

// Ambil data pengaturan stok dari database untuk info di UI
$set_notif = mysqli_fetch_array(mysqli_query($koneksi, "SELECT batas_minimum FROM setting_notif WHERE id=1"));
$batas_stok = $set_notif['batas_minimum'];

$id_k = $_SESSION['id_user'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Karyawan - Sistem Inventory</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        .stat-card { transition: transform 0.2s; border: none; border-radius: 12px; }
        .stat-card:hover { transform: translateY(-5px); }
        .badge-status { font-size: 0.75rem; padding: 6px 12px; border-radius: 20px; text-transform: uppercase; font-weight: bold; }
        .text-alasan { font-size: 0.75rem; color: #dc3545; margin-top: 5px; font-style: italic; background: #fff5f5; padding: 5px; border-radius: 5px; }
        .stok-kritis { color: #dc3545; font-weight: bold; animation: blinker 1.5s linear infinite; }
        @keyframes blinker { 50% { opacity: 0; } }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4 shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">
            <i class="bi bi-box-seam me-2"></i> PANEL GUDANG
        </a>
        <div class="ms-auto d-flex align-items-center">
            <span class="text-white me-3 d-none d-md-inline small">Halo, <b><?php echo $_SESSION['nama']; ?></b></span>
            <a href="../auth/logout.php" class="btn btn-danger btn-sm px-3 shadow-sm">
                <i class="bi bi-power me-1"></i> Keluar
            </a>
        </div>
    </div>
</nav>

<div class="container">
    <div class="row mb-4">
        <?php
        $stats = [
            ['title' => 'Menunggu', 'status' => 'pending', 'color' => 'warning', 'icon' => 'hourglass-split'],
            ['title' => 'Disetujui', 'status' => 'disetujui', 'color' => 'primary', 'icon' => 'check-circle'],
            ['title' => 'Selesai', 'status' => 'selesai', 'color' => 'success', 'icon' => 'bag-check'],
            ['title' => 'Ditolak', 'status' => 'ditolak', 'color' => 'danger', 'icon' => 'x-circle']
        ];
        foreach($stats as $s):
            $count = mysqli_num_rows(mysqli_query($koneksi, "SELECT id_pengajuan FROM pengajuan WHERE id_karyawan='$id_k' AND status='{$s['status']}'"));
        ?>
        <div class="col-6 col-md-3 mb-3">
            <div class="card stat-card shadow-sm border-start border-<?php echo $s['color']; ?> border-4 h-100">
                <div class="card-body py-3">
                    <small class="text-muted fw-bold d-block mb-1"><?php echo $s['title']; ?></small>
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="fw-bold mb-0"><?php echo $count; ?></h3>
                        <i class="bi bi-<?php echo $s['icon']; ?> fs-3 text-<?php echo $s['color']; ?> opacity-25"></i>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="row">
        <div class="col-md-5">
            <div class="card shadow border-0 mb-4">
                <div class="card-header bg-white fw-bold py-3 d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-pencil-square me-2 text-primary"></i>Input Barang Keluar</span>
                    <span class="badge bg-light text-dark border small">Stok Min: <?php echo $batas_stok; ?> Bal</span>
                </div>
                <div class="card-body">
                    <form action="proses_pengajuan.php" method="POST">
                        <div id="container-barang">
                            <div class="row mb-3 item-barang">
                                <div class="col-8">
                                    <label class="form-label small fw-bold text-muted">Produk</label>
                                    <select name="id_produk[]" class="form-select select-produk" onchange="updateMax(this)" required>
                                        <option value="">-- Pilih Rokok --</option>
                                        <?php 
                                        $produk = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY nama_rokok ASC");
                                        while($p = mysqli_fetch_array($produk)){
                                            $is_low = ($p['stok_bal'] <= $batas_stok) ? ' (STOK TIPIS!)' : '';
                                            echo "<option value='".$p['id_produk']."' data-stok='".$p['stok_bal']."'>".$p['nama_rokok']." [Sisa: ".$p['stok_bal']."]".$is_low."</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-4">
                                    <label class="form-label small fw-bold text-muted">Jumlah</label>
                                    <input type="number" name="jumlah[]" class="form-control input-jumlah" min="1" placeholder="0" required>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-light mb-3 w-100 border" onclick="tambahBaris()">
                            <i class="bi bi-plus-circle me-1 text-success"></i> Tambah Item Lain
                        </button>
                        <div class="alert alert-warning py-2 small border-0 bg-warning-subtle">
                            <i class="bi bi-info-circle me-1"></i> Admin & Finance akan menerima notifikasi jika stok mencapai batas minimum.
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2 shadow-sm fw-bold">
                            <i class="bi bi-send me-1"></i> KIRIM PENGAJUAN
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <div class="card shadow border-0">
                <div class="card-header bg-dark text-white py-3 d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-clock-history me-2"></i>Status Pengajuan Terakhir</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0 align-middle">
                            <thead class="table-light text-secondary small">
                                <tr>
                                    <th class="ps-3">TGL / JAM</th>
                                    <th>DETAIL BARANG</th>
                                    <th class="text-center">STATUS</th>
                                    <th class="text-center">AKSI</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $q_cek = mysqli_query($koneksi, "SELECT p.*, GROUP_CONCAT(CONCAT(pr.nama_rokok, ' (', pd.jumlah_bal, ' Bal)') SEPARATOR '<br>') as list_barang 
                                         FROM pengajuan p 
                                         JOIN pengajuan_detail pd ON p.id_pengajuan = pd.id_pengajuan
                                         JOIN produk pr ON pd.id_produk = pr.id_produk
                                         WHERE p.id_karyawan = '$id_k'
                                         GROUP BY p.id_pengajuan ORDER BY p.tgl_pengajuan DESC LIMIT 10");
                                
                                if(mysqli_num_rows($q_cek) == 0) echo "<tr><td colspan='4' class='text-center py-5 text-muted'>Belum ada riwayat pengajuan.</td></tr>";

                                while($row = mysqli_fetch_array($q_cek)){
                                    $status = $row['status'];
                                    $color = ($status == 'disetujui') ? 'primary' : (($status == 'selesai') ? 'success' : (($status == 'ditolak') ? 'danger' : 'warning'));
                                ?>
                                    <tr>
                                        <td class="ps-3">
                                            <span class="d-block fw-bold small"><?php echo date('d M Y', strtotime($row['tgl_pengajuan'])); ?></span>
                                            <small class="text-muted"><?php echo date('H:i', strtotime($row['tgl_pengajuan'])); ?> WIB</small>
                                        </td>
                                        <td style="font-size: 0.85rem;" class="py-3"><?php echo $row['list_barang']; ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-<?php echo $color; ?>-subtle text-<?php echo $color; ?> badge-status">
                                                <?php echo $status; ?>
                                            </span>
                                            <?php if($status == 'ditolak' && !empty($row['alasan_tolak'])): ?>
                                                <div class="text-alasan mx-auto" style="max-width: 150px;">
                                                    <i class="bi bi-info-circle me-1"></i><?php echo htmlspecialchars($row['alasan_tolak']); ?>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?php if($status == 'disetujui' || $status == 'selesai'): ?>
                                                <a href="cetak_bon.php?id=<?php echo $row['id_pengajuan']; ?>" class="btn btn-sm btn-outline-dark rounded-circle" title="Cetak Surat Jalan">
                                                    <i class="bi bi-printer"></i>
                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Fungsi untuk membatasi input jumlah agar tidak melebihi stok fisik
function updateMax(selectElement) {
    var selectedOption = selectElement.options[selectElement.selectedIndex];
    var stok = selectedOption.getAttribute('data-stok');
    var inputJumlah = selectElement.closest('.row').querySelector('.input-jumlah');
    if(stok) {
        inputJumlah.setAttribute('max', stok);
        inputJumlah.setAttribute('placeholder', 'Max ' + stok);
    } else {
        inputJumlah.removeAttribute('max');
        inputJumlah.setAttribute('placeholder', '0');
    }
}

// Fungsi menambah item produk (Multi-item pengajuan)
function tambahBaris() {
    var container = document.getElementById("container-barang");
    var row = document.createElement("div");
    row.className = "row mb-3 item-barang border-top pt-3 animate__animated animate__fadeIn";
    row.innerHTML = `
        <div class="col-8">
            <select name="id_produk[]" class="form-select" onchange="updateMax(this)" required>
                <option value="">-- Pilih Rokok --</option>
                <?php 
                mysqli_data_seek($produk, 0); // Reset pointer query
                while($p2 = mysqli_fetch_array($produk)){
                    echo "<option value='".$p2['id_produk']."' data-stok='".$p2['stok_bal']."'>".$p2['nama_rokok']." [Sisa: ".$p2['stok_bal']."]</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-3">
            <input type="number" name="jumlah[]" class="form-control input-jumlah" min="1" placeholder="0" required>
        </div>
        <div class="col-1 p-0 d-flex align-items-center">
            <button type="button" class="btn btn-sm text-danger" onclick="this.closest('.row').remove()">
                <i class="bi bi-trash fs-5"></i>
            </button>
        </div>
    `;
    container.appendChild(row);
}
</script>
</body>
</html>