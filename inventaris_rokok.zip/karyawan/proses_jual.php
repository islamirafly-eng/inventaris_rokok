<?php
include '../config/koneksi.php';
include '../config/fungsi_wa.php'; // Panggil fungsi WA yang dibuat tadi

$id_produk    = $_POST['id_produk'];
$jumlah_jual  = $_POST['jumlah'];
$nomor_wa_bos = "6283115732528"; // Ganti dengan nomor WA Anda (Awali dengan 08/62)

// 1. Ambil data stok saat ini
$query_stok = mysqli_query($koneksi, "SELECT nama_rokok, stok_bal FROM produk WHERE id_produk='$id_produk'");
$data = mysqli_fetch_array($query_stok);
$stok_sekarang = $data['stok_bal'];
$nama_produk   = $data['nama_rokok'];

// 2. Cek apakah stok cukup
if($stok_sekarang < $jumlah_jual) {
    header("location:input_jual.php?pesan=stok_kurang");
} else {
    // 3. Update stok di database
    $stok_baru = $stok_sekarang - $jumlah_jual;
    mysqli_query($koneksi, "UPDATE produk SET stok_bal = '$stok_baru' WHERE id_produk = '$id_produk'");
    
    // Simpan riwayat penjualan
    mysqli_query($koneksi, "INSERT INTO penjualan (id_produk, jumlah_jual, tgl_jual) VALUES ('$id_produk', '$jumlah_jual', NOW())");

    // 4. CEK APAKAH STOK MENIPIS (Batas minimal misal 10 Bal)
    if($stok_baru <= 10) {
        $pesan_wa = "⚠️ *PERINGATAN STOK TIPIS* ⚠️\n\n" .
                    "Stok produk berikut hampir habis:\n" .
                    "Produk: * $nama_produk *\n" .
                    "Sisa Stok: * $stok_baru Bal *\n\n" .
                    "Mohon segera lakukan pengadaan stok kembali.";
        
        kirimNotifWA($nomor_wa_bos, $pesan_wa);
    }

    header("location:dashboard.php?pesan=berhasil");
}
?>