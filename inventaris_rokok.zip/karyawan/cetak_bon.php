<?php
session_start();
if($_SESSION['role'] != "karyawan"){
    header("location:../index.php");
    exit();
}
include '../config/koneksi.php';

$id_p = $_GET['id'];
$id_k = $_SESSION['id_user'];

// Ambil data pengajuan dan pastikan ini milik karyawan yang login
$query = mysqli_query($koneksi, "SELECT p.*, u.nama_lengkap FROM pengajuan p 
         JOIN users u ON p.id_karyawan = u.id_user 
         WHERE p.id_pengajuan = '$id_p' AND p.id_karyawan = '$id_k'");
$data = mysqli_fetch_array($query);

if(!$data) { echo "Data tidak ditemukan!"; exit(); }
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Bon Pengambilan Barang #<?php echo $id_p; ?></title>
    <style>
        body { font-family: 'Courier New', Courier, monospace; font-size: 12px; color: #333; }
        .wrapper { width: 500px; margin: auto; border: 1px solid #eee; padding: 20px; }
        .header { text-align: center; border-bottom: 2px dashed #000; padding-bottom: 10px; margin-bottom: 15px; }
        .info-table { width: 100%; margin-bottom: 20px; }
        .item-table { width: 100%; border-collapse: collapse; }
        .item-table th { border-bottom: 1px solid #000; text-align: left; padding: 5px; }
        .item-table td { padding: 5px; border-bottom: 1px dotted #ccc; }
        .footer { margin-top: 30px; display: flex; justify-content: space-between; text-align: center; }
        .signature { width: 150px; }
        @media print {
            .no-print { display: none; }
            body { background: #fff; }
            .wrapper { border: none; width: 100%; }
        }
    </style>
</head>
<body onload="window.print()">

<div class="no-print" style="background: #fff3cd; padding: 10px; text-align: center; margin-bottom: 20px;">
    <strong>Mode Pratinjau Cetak</strong><br>
    <button onclick="window.print()">Klik Cetak</button> 
    <button onclick="window.history.back()">Kembali</button>
</div>

<div class="wrapper">
    <div class="header">
        <h2 style="margin: 0;">BON PENGAMBILAN BARANG</h2>
        <p style="margin: 5px 0;">Sistem Inventory Rokok - No: #REQ-<?php echo str_pad($id_p, 5, '0', STR_PAD_LEFT); ?></p>
    </div>

    <table class="info-table">
        <tr>
            <td><strong>Nama Karyawan</strong></td>
            <td>: <?php echo $data['nama_lengkap']; ?></td>
        </tr>
        <tr>
            <td><strong>Tanggal Pengajuan</strong></td>
            <td>: <?php echo date('d/m/Y H:i', strtotime($data['tgl_pengajuan'])); ?></td>
        </tr>
        <tr>
            <td><strong>Status</strong></td>
            <td>: <?php echo strtoupper($data['status']); ?></td>
        </tr>
    </table>

    <table class="item-table">
        <thead>
            <tr>
                <th>Nama Produk</th>
                <th style="text-align: center;">Jumlah</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $detail = mysqli_query($koneksi, "SELECT pd.*, pr.nama_rokok FROM pengajuan_detail pd 
                      JOIN produk pr ON pd.id_produk = pr.id_produk 
                      WHERE pd.id_pengajuan = '$id_p'");
            while($d = mysqli_fetch_array($detail)){
            ?>
            <tr>
                <td><?php echo $d['nama_rokok']; ?></td>
                <td style="text-align: center;"><?php echo $d['jumlah_bal']; ?> Bal</td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

    <div class="footer">
        <div class="signature">
            <p>Hormat Kami,</p>
            <br><br>
            <p>( <?php echo $data['nama_lengkap']; ?> )</p>
            <small>Karyawan</small>
        </div>
        <div class="signature">
            <p>Mengetahui,</p>
            <br><br>
            <p>( ............... )</p>
            <small>Admin Gudang</small>
        </div>
    </div>

    <div style="margin-top: 30px; font-size: 10px; text-align: center; color: #888;">
        *Harap simpan bon ini sebagai bukti pengambilan barang yang sah.
    </div>
</div>

</body>
</html>