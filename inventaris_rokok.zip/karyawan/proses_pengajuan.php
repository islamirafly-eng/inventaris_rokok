<?php
session_start();
// Pastikan koneksi dan fungsi WA disertakan
include '../config/koneksi.php';
include '../config/fungsi_wa.php';

// Proteksi: Hanya karyawan yang bisa memproses
if ($_SESSION['role'] != "karyawan") {
    header("location:../index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id_produk'])) {
    $id_karyawan = $_SESSION['id_user'];
    $id_produk_array = $_POST['id_produk'];
    $jumlah_array = $_POST['jumlah'];
    
    // Batas minimum untuk pemicu WhatsApp
    $batas_wa = 10; 

    // --- MULAI TRANSAKSI ---
    mysqli_begin_transaction($koneksi);

    try {
        // 1. Simpan Header Pengajuan
        $sql_header = mysqli_query($koneksi, "INSERT INTO pengajuan (id_karyawan, tgl_pengajuan, status) VALUES ('$id_karyawan', NOW(), 'pending')");
        
        if (!$sql_header) {
            throw new Exception("Gagal membuat header pengajuan.");
        }

        $id_pengajuan_baru = mysqli_insert_id($koneksi);

        // 2. Simpan Detail & Cek Notifikasi WA
        foreach($id_produk_array as $index => $id_produk) {
            $id_p = mysqli_real_escape_string($koneksi, $id_produk);
            $jumlah = (int)$jumlah_array[$index];

            if ($jumlah <= 0) continue; 

            // LOCK BARIS untuk validasi stok
            $q_cek_stok = mysqli_query($koneksi, "SELECT nama_rokok, stok_bal FROM produk WHERE id_produk = '$id_p' FOR UPDATE");
            $data_produk = mysqli_fetch_assoc($q_cek_stok);

            // Validasi Stok Fisik
            if ($data_produk['stok_bal'] < $jumlah) {
                throw new Exception("Stok rokok " . $data_produk['nama_rokok'] . " tidak mencukupi (Tersisa: " . $data_produk['stok_bal'] . ").");
            }

            // Simpan ke detail pengajuan
            $sql_detail = mysqli_query($koneksi, "INSERT INTO pengajuan_detail (id_pengajuan, id_produk, jumlah_bal) 
                                                  VALUES ('$id_pengajuan_baru', '$id_p', '$jumlah')");
            
            if (!$sql_detail) {
                throw new Exception("Gagal menyimpan detail produk.");
            }

            // --- LOGIKA NOTIFIKASI WHATSAPP ---
            // Cek apakah stok saat ini (sebelum dikurangi) sudah mencapai batas minimum
            if ($data_produk['stok_bal'] <= $batas_wa) {
                kirimNotifWA($data_produk['nama_rokok'], $data_produk['stok_bal']);
            }
        }

        // --- COMMIT ---
        mysqli_commit($koneksi);
        header("location:dashboard.php?pesan=berhasil_kirim");

    } catch (Exception $e) {
        // --- ROLLBACK ---
        mysqli_rollback($koneksi);
        
        $pesan_error = urlencode($e->getMessage());
        header("location:dashboard.php?pesan=error&detail=$pesan_error");
    }

} else {
    header("location:dashboard.php");
}
?>