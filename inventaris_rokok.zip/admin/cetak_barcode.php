<?php 
include '../config/koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Label Barcode</title>
    <style>
        body { font-family: sans-serif; background-color: #f0f0f0; margin: 0; padding: 20px; }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 15px;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .barcode-card {
            border: 1px solid #ddd;
            padding: 15px;
            text-align: center;
            border-radius: 8px;
            background: #fff;
        }
        .barcode-card h4 { margin: 0 0 5px 0; font-size: 14px; text-transform: uppercase; color: #333; }
        .barcode-card p { margin: 5px 0 0 0; font-size: 12px; font-weight: bold; color: #666; }
        .barcode-img { width: 100%; height: auto; max-height: 60px; margin: 10px 0; }
        
        @media print {
            body { background: none; padding: 0; }
            .grid-container { box-shadow: none; border: none; }
            .no-print { display: none; }
            .barcode-card { border: 1px solid #000; } /* Pertegas garis saat diprint */
        }
        
        .btn-print {
            background: #1a1a1a; color: white; border: none; padding: 10px 20px;
            border-radius: 5px; cursor: pointer; font-weight: bold; margin-bottom: 20px;
        }
    </style>
</head>
<body>

    <div class="no-print">
        <button onclick="window.print()" class="btn-print">🖨️ CETAK LABEL SEKARANG</button>
        <p><small>*Gunakan kertas stiker A4 untuk hasil terbaik.</small></p>
    </div>

    <div class="grid-container">
        <?php 
        $data = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY nama_rokok ASC");
        while($d = mysqli_fetch_array($data)){
            // Kita gunakan API bwip-js untuk barcode linear (Code 128) yang profesional
            $barcode_url = "https://bwipjs-api.metafloor.com/?bcid=code128&text=" . $d['kode_barcode'] . "&scale=2&rotate=N&includetext";
        ?>
            <div class="barcode-card">
                <h4><?php echo $d['nama_rokok']; ?></h4>
                <img src="<?php echo $barcode_url; ?>" alt="Barcode" class="barcode-img">
                <p><?php echo $d['kode_barcode']; ?></p>
            </div>
        <?php } ?>
    </div>

</body>
</html>