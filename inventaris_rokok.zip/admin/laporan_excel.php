<?php
include '../config/koneksi.php';

// Perintah agar browser mendownload file sebagai Excel
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Inventaris_Rokok_".date('d-m-Y').".xls");
?>

<center>
    <h2>LAPORAN INVENTARIS STOK ROKOK</h2>
    <p>Tanggal Cetak: <?php echo date('d-m-Y H:i'); ?></p>
</center>

<table border="1">
    <thead>
        <tr style="background-color: #f2f2f2;">
            <th>No</th>
            <th>Kode Barcode</th>
            <th>Nama Merk Rokok</th>
            <th>Tahun Cukai</th>
            <th>Stok Sisa (Bal)</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $no = 1;
        $query = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY nama_rokok ASC");
        while($d = mysqli_fetch_array($query)){
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td>'<?php echo $d['kode_barcode']; ?></td> <td><?php echo $d['nama_rokok']; ?></td>
                <td><?php echo $d['tahun_cukai']; ?></td>
                <td><?php echo $d['stok_bal']; ?></td>
            </tr>
            <?php 
        }
        ?>
    </tbody>
</table>

<br>
<table border="1">
    <thead>
        <tr style="background-color: #f2f2f2;">
            <th colspan="4">RIWAYAT PENGELUARAN BARANG (SERAH TERIMA)</th>
        </tr>
        <tr>
            <th>Tanggal</th>
            <th>Karyawan</th>
            <th>Nama Barang</th>
            <th>Jumlah (Bal)</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $q_log = mysqli_query($koneksi, "SELECT p.tgl_pengajuan, u.nama_lengkap, pr.nama_rokok, pd.jumlah_bal 
                 FROM pengajuan p 
                 JOIN users u ON p.id_karyawan = u.id_user 
                 JOIN pengajuan_detail pd ON p.id_pengajuan = pd.id_pengajuan
                 JOIN produk pr ON pd.id_produk = pr.id_produk
                 WHERE p.status = 'selesai'
                 ORDER BY p.tgl_pengajuan DESC");
        
        while($log = mysqli_fetch_array($q_log)){
            echo "<tr>
                    <td>".$log['tgl_pengajuan']."</td>
                    <td>".$log['nama_lengkap']."</td>
                    <td>".$log['nama_rokok']."</td>
                    <td>".$log['jumlah_bal']."</td>
                  </tr>";
        }
        ?>
    </tbody>
</table>