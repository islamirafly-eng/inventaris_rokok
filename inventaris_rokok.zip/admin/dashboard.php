<?php 
session_start();
if($_SESSION['role'] != "admin"){
    header("location:../index.php?pesan=bukan_admin");
    exit();
}
include '../config/koneksi.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Inventaris Rokok</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="https://unpkg.com/html5-qrcode"></script>
    <style>
        :root { --dark-bg: #1a1a1a; }
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .navbar { background-color: var(--dark-bg) !important; }
        .table-responsive { max-height: 450px; overflow-y: auto; }
        .card { border-radius: 12px; border: none; margin-bottom: 20px; }
        .sticky-top { top: 0; z-index: 10; }
        .barcode-preview { filter: grayscale(1); opacity: 0.6; transition: 0.3s; }
        .barcode-preview:hover { filter: grayscale(0); opacity: 1; }
        #reader { border-radius: 12px; overflow: hidden; border: none !important; }
        .btn-action { font-weight: 600; letter-spacing: 0.5px; }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark shadow mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#"><i class="bi bi-box-fill me-2"></i> ADMIN PANEL</a>
        <div class="d-flex align-items-center">
            <a href="laporan_excel.php" class="btn btn-outline-success btn-sm me-2"><i class="bi bi-file-earmark-excel"></i> Excel</a>
            <a href="../auth/logout.php" class="btn btn-danger btn-sm shadow-sm"><i class="bi bi-power"></i> Keluar</a>
        </div>
    </div>
</nav>

<div class="container">
    <div class="row mb-3">
        <div class="col-12">
            <div class="bg-white p-3 rounded shadow-sm d-flex flex-wrap justify-content-between align-items-center gap-2">
                <h5 class="m-0 fw-bold text-dark"><i class="bi bi-cpu me-2 text-primary"></i>Sistem Kontrol Gudang</h5>
                <div class="d-flex gap-2">
                    <a href="cek_stok.php" class="btn btn-primary btn-sm shadow-sm btn-action">
                        <i class="bi bi-search-heart me-1"></i> CEK STOK (SCAN)
                    </a>
                    <a href="cetak_barcode.php" target="_blank" class="btn btn-dark btn-sm shadow-sm btn-action">
                        <i class="bi bi-printer me-1"></i> CETAK SEMUA LABEL
                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php if(isset($_GET['pesan'])): ?>
        <div class="alert <?php echo ($_GET['pesan'] == 'stok_kurang' ? 'alert-danger' : 'alert-success'); ?> alert-dismissible fade show shadow-sm border-0 mb-4" role="alert">
            <i class="bi <?php echo ($_GET['pesan'] == 'stok_kurang' ? 'bi-exclamation-triangle-fill' : 'bi-check-circle-fill'); ?> me-2"></i>
            <?php 
                if($_GET['pesan'] == 'stok_kurang') echo "<strong>GAGAL:</strong> Stok tidak cukup untuk " . urldecode($_GET['barang']);
                if($_GET['pesan'] == 'serah_terima_berhasil') echo "<strong>BERHASIL:</strong> Barang telah diserahkan dan stok otomatis terpotong.";
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white fw-bold py-3">
                    <i class="bi bi-plus-square me-2"></i> Tambah Barang Baru
                </div>
                <div class="card-body">
                    <form action="proses_tambah.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Scan Barcode / Input Manual</label>
                            <div id="reader" class="mb-2 border rounded bg-dark"></div> 
                            <input type="text" name="kode_barcode" id="result" class="form-control" placeholder="Kode Barcode" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Nama Merk Rokok</label>
                            <input type="text" name="nama_rokok" class="form-control" required placeholder="Nama Produk">
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Tahun Cukai</label>
                            <input type="number" name="tahun_cukai" class="form-control" value="2026">
                        </div>
                        <button type="submit" class="btn btn-success w-100 shadow-sm py-2 fw-bold text-uppercase">SIMPAN KE GUDANG</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-dark text-white fw-bold py-3">
                    <i class="bi bi-archive me-2"></i> Stok Gudang Saat Ini (Bal)
                </div>
                <div class="card-body p-0 table-responsive">
                    <table class="table table-hover mb-0 align-middle text-nowrap">
                        <thead class="table-light sticky-top">
                            <tr>
                                <th class="ps-3">Visual Barcode</th>
                                <th>Produk</th>
                                <th>Cukai</th>
                                <th>Stok</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $query = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY nama_rokok ASC");
                            while($d = mysqli_fetch_array($query)){
                            ?>
                                <tr>
                                    <td class="ps-3">
                                        <img src="https://bwipjs-api.metafloor.com/?bcid=code128&text=<?php echo $d['kode_barcode']; ?>&scale=1&rotate=N" class="barcode-preview" style="height: 25px;">
                                        <br><small class="text-muted"><code><?php echo $d['kode_barcode']; ?></code></small>
                                    </td>
                                    <td class="fw-bold"><?php echo $d['nama_rokok']; ?></td>
                                    <td><?php echo $d['tahun_cukai']; ?></td>
                                    <td>
                                        <?php if($d['stok_bal'] <= 5): ?>
                                            <span class="badge bg-danger rounded-pill px-3">Kritis: <?php echo $d['stok_bal']; ?></span>
                                        <?php elseif($d['stok_bal'] <= 15): ?>
                                            <span class="badge bg-warning text-dark rounded-pill px-3">Tipis: <?php echo $d['stok_bal']; ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-primary rounded-pill px-3"><?php echo $d['stok_bal']; ?> Bal</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-2">
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-warning text-dark fw-bold py-3">
                    <i class="bi bi-clock-history me-2"></i> Antrean Penyerahan Barang
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Karyawan</th>
                                    <th>Daftar Permintaan</th>
                                    <th>Waktu</th>
                                    <th class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $q_serah = mysqli_query($koneksi, "SELECT p.*, u.nama_lengkap FROM pengajuan p 
                                           JOIN users u ON p.id_karyawan = u.id_user 
                                           WHERE p.status = 'disetujui' ORDER BY p.tgl_pengajuan DESC");
                                
                                if(mysqli_num_rows($q_serah) == 0) echo "<tr><td colspan='4' class='text-center text-muted py-5'>Tidak ada antrean saat ini.</td></tr>";

                                while($row = mysqli_fetch_array($q_serah)){
                                    $id_p = $row['id_pengajuan'];
                                ?>
                                <tr>
                                    <td><strong><?php echo $row['nama_lengkap']; ?></strong></td>
                                    <td>
                                        <ul class="mb-0 small text-muted p-0" style="list-style: none;">
                                            <?php 
                                            $q_det = mysqli_query($koneksi, "SELECT pd.*, pr.nama_rokok FROM pengajuan_detail pd 
                                                     JOIN produk pr ON pd.id_produk = pr.id_produk WHERE pd.id_pengajuan = '$id_p'");
                                            while($det = mysqli_fetch_array($q_det)){
                                                echo "<li><i class='bi bi-dot'></i> ".$det['nama_rokok']." (<b>".$det['jumlah_bal']." Bal</b>)</li>";
                                            }
                                            ?>
                                        </ul>
                                    </td>
                                    <td class="small"><?php echo date('d M, H:i', strtotime($row['tgl_pengajuan'])); ?></td>
                                    <td class="text-center">
                                        <a href="proses_serah_terima.php?id=<?php echo $id_p; ?>" class="btn btn-primary btn-sm px-4 fw-bold shadow-sm" onclick="return confirm('Serahkan barang ini?')">SERAHKAN</a>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-success text-white fw-bold py-3">
                    <i class="bi bi-journal-check me-2"></i> 5 Penyerahan Terakhir (Selesai)
                </div>
                <div class="card-body p-0">
                    <table class="table table-sm table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3">Waktu</th>
                                <th>Penerima</th>
                                <th>Barang</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $q_history = mysqli_query($koneksi, "SELECT p.*, u.nama_lengkap FROM pengajuan p 
                                         JOIN users u ON p.id_karyawan = u.id_user 
                                         WHERE p.status = 'selesai' ORDER BY p.id_pengajuan DESC LIMIT 5");

                            while($h = mysqli_fetch_array($q_history)){
                                $id_h = $h['id_pengajuan'];
                            ?>
                            <tr>
                                <td class="ps-3 small"><?php echo date('d/m/y H:i', strtotime($h['tgl_pengajuan'])); ?></td>
                                <td><span class="small fw-bold"><?php echo $h['nama_lengkap']; ?></span></td>
                                <td class="small text-muted italic">
                                    <?php 
                                    $q_hdet = mysqli_query($koneksi, "SELECT pd.*, pr.nama_rokok FROM pengajuan_detail pd 
                                              JOIN produk pr ON pd.id_produk = pr.id_produk WHERE pd.id_pengajuan = '$id_h'");
                                    $items_h = [];
                                    while($hdet = mysqli_fetch_array($q_hdet)) { $items_h[] = $hdet['nama_rokok']." (".$hdet['jumlah_bal'].")"; }
                                    echo implode(", ", $items_h);
                                    ?>
                                </td>
                                <td><span class="badge bg-light text-success border border-success">Selesai</span></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script>
    function onScanSuccess(decodedText, decodedResult) {
        document.getElementById('result').value = decodedText;
        document.getElementById('result').style.backgroundColor = "#d1e7dd";
    }
    let html5QrcodeScanner = new Html5QrcodeScanner("reader", { fps: 15, qrbox: 200 });
    html5QrcodeScanner.render(onScanSuccess);
</script>

</body>
</html>