<?php
include '../config/koneksi.php';

$barcode = $_GET['barcode'];
$query = mysqli_query($koneksi, "SELECT * FROM produk WHERE kode_barcode = '$barcode'");
$cek = mysqli_num_rows($query);

if($cek > 0) {
    $d = mysqli_fetch_array($query);
    echo json_encode([
        'status' => 'ketemu',
        'nama' => $d['nama_rokok'],
        'stok' => $d['stok_bal'],
        'cukai' => $d['tahun_cukai']
    ]);
} else {
    echo json_encode(['status' => 'tidak_ada']);
}
?>