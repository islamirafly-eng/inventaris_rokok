<?php 
session_start();
if($_SESSION['role'] != "admin"){
    header("location:../index.php?pesan=bukan_admin");
    exit();
}
include '../config/koneksi.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cek Stok Instan - Scan Barcode</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="https://unpkg.com/html5-qrcode"></script>
    <style>
        body { background-color: #121212; color: white; }
        .scanner-wrapper { max-width: 500px; margin: auto; padding: 20px; }
        #reader { border-radius: 15px; overflow: hidden; border: 2px solid #333 !important; }
        .result-card { display: none; margin-top: 20px; border: none; border-radius: 15px; background: #1e1e1e; color: white; }
        .stok-angka { font-size: 3rem; font-weight: bold; }
    </style>
</head>
<body>

<div class="scanner-wrapper text-center">
    <div class="mb-4">
        <a href="dashboard.php" class="btn btn-outline-light btn-sm float-start"><i class="bi bi-arrow-left"></i> Kembali</a>
        <h5 class="fw-bold">CEK STOK INSTAN</h5>
    </div>

    <div id="reader" class="shadow-lg"></div>
    
    <div class="mt-3 p-2 bg-secondary rounded-pill small">
        <i class="bi bi-info-circle me-1"></i> Arahkan kamera ke Barcode produk
    </div>

    <div id="hasil-pencarian" class="card result-card shadow-lg text-start">
        <div class="card-body p-4">
            <h6 class="text-secondary text-uppercase small mb-1">Nama Produk</h6>
            <h3 id="nama-produk" class="fw-bold text-primary mb-3">-</h3>
            
            <div class="row text-center">
                <div class="col-6 border-end">
                    <h6 class="text-secondary small">Sisa Stok</h6>
                    <div id="jumlah-stok" class="stok-angka text-white">0</div>
                    <span class="badge bg-primary">BAL</span>
                </div>
                <div class="col-6">
                    <h6 class="text-secondary small">Tahun Cukai</h6>
                    <div id="tahun-cukai" class="h2 mt-2 fw-bold">-</div>
                </div>
            </div>

            <hr class="border-secondary">
            <div id="status-stok" class="text-center fw-bold small"></div>
        </div>
    </div>

    <button id="btn-ulang" class="btn btn-outline-primary w-100 mt-3 d-none" onclick="location.reload()">
        <i class="bi bi-arrow-repeat"></i> Scan Barang Lain
    </button>
</div>

<script>
    function onScanSuccess(decodedText, decodedResult) {
        // Hentikan scanner setelah berhasil scan agar tidak duplikat
        html5QrcodeScanner.clear();
        
        // Kirim data ke server via Fetch API untuk cek stok
        fetch('get_stok.php?barcode=' + decodedText)
        .then(response => response.json())
        .then(data => {
            document.getElementById('hasil-pencarian').style.display = 'block';
            document.getElementById('btn-ulang').classList.remove('d-none');

            if(data.status == 'ketemu') {
                document.getElementById('nama-produk').innerText = data.nama;
                document.getElementById('jumlah-stok').innerText = data.stok;
                document.getElementById('tahun-cukai').innerText = data.cukai;
                
                let statusEl = document.getElementById('status-stok');
                if(data.stok <= 10) {
                    statusEl.innerHTML = '<span class="text-danger"><i class="bi bi-exclamation-triangle"></i> STOK KRITIS! SEGERA ORDER</span>';
                } else {
                    statusEl.innerHTML = '<span class="text-success"><i class="bi bi-check-circle"></i> STOK AMAN</span>';
                }
            } else {
                document.getElementById('nama-produk').innerText = "PRODUK TIDAK TERDAFTAR";
                document.getElementById('nama-produk').classList.replace('text-primary', 'text-danger');
            }
        });
    }

    let html5QrcodeScanner = new Html5QrcodeScanner("reader", { fps: 10, qrbox: 250 });
    html5QrcodeScanner.render(onScanSuccess);
</script>

</body>
</html>