<?php
session_start();
include '../config/koneksi.php';

// Proteksi agar hanya admin yang bisa akses file ini
if($_SESSION['role'] != "admin"){ 
    header("location:../index.php");
    exit(); 
}

$id_p     = mysqli_real_escape_string($koneksi, $_GET['id']);
$id_admin = $_SESSION['id_user'];

// --- MULAI TRANSAKSI (Mencegah Race Condition) ---
mysqli_begin_transaction($koneksi);

try {
    // 1. Ambil semua item (rokok) yang ada dalam pengajuan ini
    // Kita gunakan JOIN ke tabel produk agar bisa mengunci baris stoknya
    $items = mysqli_query($koneksi, "SELECT pd.*, p.nama_rokok, p.stok_bal 
                                     FROM pengajuan_detail pd 
                                     JOIN produk p ON pd.id_produk = p.id_produk 
                                     WHERE pd.id_pengajuan = '$id_p' FOR UPDATE");

    if(mysqli_num_rows($items) == 0) {
        throw new Exception("Data pengajuan tidak ditemukan.");
    }

    // 2. Loop untuk memotong stok setiap barang dengan validasi ketat
    while($row = mysqli_fetch_array($items)){
        $id_produk = $row['id_produk'];
        $jml_minta = $row['jumlah_bal'];
        $stok_saat_ini = $row['stok_bal'];
        $nama_barang = $row['nama_rokok'];

        // CEK REAL-TIME: Pastikan stok cukup saat tombol diklik
        if($stok_saat_ini < $jml_minta) {
            throw new Exception("Stok untuk $nama_barang tidak mencukupi (Sisa: $stok_saat_ini).");
        }

        // Update stok: Stok Lama - Jumlah yang diminta
        $update_stok = mysqli_query($koneksi, "UPDATE produk SET stok_bal = stok_bal - $jml_minta WHERE id_produk = '$id_produk'");
        
        if(!$update_stok) throw new Exception("Gagal update stok $nama_barang.");
    }

    // 3. Catat bukti penyerahan ke tabel serah_terima
    $ins_serah = mysqli_query($koneksi, "INSERT INTO serah_terima (id_pengajuan, id_admin) VALUES ('$id_p', '$id_admin')");
    if(!$ins_serah) throw new Exception("Gagal mencatat bukti serah terima.");

    // 4. Ubah status pengajuan menjadi 'selesai'
    $upd_status = mysqli_query($koneksi, "UPDATE pengajuan SET status = 'selesai' WHERE id_pengajuan = '$id_p'");
    if(!$upd_status) throw new Exception("Gagal memperbarui status pengajuan.");

    // --- JIKA SEMUA BERHASIL, SIMPAN PERMANEN ---
    mysqli_commit($koneksi);
    header("location:dashboard.php?pesan=serah_terima_berhasil");

} catch (Exception $e) {
    // --- JIKA ADA ERROR (MISAL STOK KURANG), BATALKAN SEMUA ---
    mysqli_rollback($koneksi);
    
    // Kirim pesan error spesifik ke dashboard
    $error_msg = urlencode($e->getMessage());
    header("location:dashboard.php?pesan=stok_kurang&barang=$error_msg");
}
?>