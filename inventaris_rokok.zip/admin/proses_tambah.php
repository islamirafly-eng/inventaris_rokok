<?php
session_start();
include '../config/koneksi.php';

// Proteksi halaman: pastikan hanya admin yang bisa memproses
if ($_SESSION['role'] != "admin") {
    header("location:../index.php?pesan=bukan_admin");
    exit();
}

// Menangkap data yang dikirim dari form dashboard
$kode_barcode = mysqli_real_escape_string($koneksi, $_POST['kode_barcode']);
$nama_rokok   = mysqli_real_escape_string($koneksi, $_POST['nama_rokok']);
$tahun_cukai  = mysqli_real_escape_string($koneksi, $_POST['tahun_cukai']);

// Secara default, saat pendaftaran barang baru, stok kita set 0 
// karena penambahan stok fisik biasanya dilakukan lewat alur "Membeli Barang" (Keuangan)
$stok_awal    = 0; 

// Validasi: Cek apakah kode barcode sudah ada sebelumnya di database
$cek_barcode = mysqli_query($koneksi, "SELECT * FROM produk WHERE kode_barcode = '$kode_barcode'");

if (mysqli_num_rows($cek_barcode) > 0) {
    // Jika barcode sudah ada, kembali ke dashboard dengan peringatan
    header("location:dashboard.php?pesan=barcode_sudah_ada");
} else {
    // Jika belum ada, masukkan data ke tabel produk
    $simpan = mysqli_query($koneksi, "INSERT INTO produk (kode_barcode, nama_rokok, tahun_cukai, stok_bal) 
                                      VALUES ('$kode_barcode', '$nama_rokok', '$tahun_cukai', '$stok_awal')");
    
    if ($simpan) {
        header("location:dashboard.php?pesan=berhasil_tambah");
    } else {
        header("location:dashboard.php?pesan=gagal_tambah");
    }
}
?>