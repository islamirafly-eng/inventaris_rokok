<?php
function kirimNotifWA($nama_produk, $sisa_stok) {
    global $koneksi;

    // Data yang Anda berikan
    $target = "6283115732528"; 
    $token  = "x1rvey8Ers8HLKn2Gt8T"; 
    
    // Format Pesan Profesional
    $pesan = "⚠️ *NOTIFIKASI STOK INVENTORI* ⚠️\n\n";
    $pesan .= "Halo Admin, sistem mendeteksi stok barang berikut sudah menipis:\n\n";
    $pesan .= "📦 *Produk:* " . $nama_produk . "\n";
    $pesan .= "📉 *Sisa Stok:* " . $sisa_stok . " Bal\n\n";
    $pesan .= "📅 *Waktu:* " . date('d/m/Y H:i') . " WIB\n";
    $pesan .= "Mohon segera lakukan pengadaan barang agar operasional tidak terganggu.";

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.fonnte.com/send',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array(
            'target' => $target,
            'message' => $pesan,
            'countryCode' => '62', 
        ),
        CURLOPT_HTTPHEADER => array(
            "Authorization: $token"
        ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
}
?>