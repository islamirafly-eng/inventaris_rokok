<?php
session_start();
include '../config/koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];

$query = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$username' AND password='$password'");
$cek = mysqli_num_rows($query);

if($cek > 0){
    $data = mysqli_fetch_assoc($query);
    
    // Simpan data user ke session
    $_SESSION['id_user']  = $data['id_user'];
    $_SESSION['username'] = $data['username'];
    $_SESSION['nama']     = $data['nama_lengkap'];
    $_SESSION['role']     = $data['role'];
    

    // Redirect sesuai role
    if($data['role'] == "admin"){
        header("location:../admin/dashboard.php");
    } else if($data['role'] == "atasan"){
        header("location:../atasan/dashboard.php");
    } else if($data['role'] == "keuangan"){
        header("location:../keuangan/dashboard.php");
    } else if($data['role'] == "karyawan"){
        header("location:../karyawan/dashboard.php");
    }
} else {
    header("location:../index.php?pesan=gagal");
}
?>