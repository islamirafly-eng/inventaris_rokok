<?php 
session_start();
// Hapus semua variabel session
session_unset();
// Hancurkan session
session_destroy();

// Alihkan kembali ke halaman login depan
header("location:../index.php?pesan=logout");
exit();
?>