<?php 
session_start();
// KODE PENGAMAN: Hanya Atasan yang boleh masuk
if($_SESSION['role'] != "atasan"){
    header("location:../index.php?pesan=bukan_atasan");
    exit();
}
include '../config/koneksi.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Atasan - Persetujuan Barang</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <style>
        .stat-card { transition: transform 0.2s; border: none; }
        .stat-card:hover { transform: translateY(-5px); }
        .stok-peringatan { font-size: 0.75rem; color: #dc3545; font-weight: bold; }
        .table-scroll { max-height: 600px; overflow-y: auto; }
        .sticky-th { position: sticky; top: 0; background-color: #f8f9fa !important; z-index: 10; box-shadow: 0 2px 2px -1px rgba(0,0,0,0.1); }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4 shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">
            <i class="bi bi-box-seam"></i> Panel Karyawan - (<?php echo $_SESSION['nama']; ?>)
        </a>
        <div class="d-flex">
            <a href="../auth/logout.php" class="btn btn-danger btn-sm shadow-sm">
                <i class="bi bi-power"></i> Keluar
            </a>
        </div>
    </div>
</nav>

<div class="container">
    
    <?php if(isset($_GET['pesan']) && $_GET['pesan'] == 'gagal_stok'): ?>
        <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
            <strong>Gagal Menyetujui!</strong> Stok <b><?php echo $_GET['barang']; ?></b> sudah tidak mencukupi di gudang.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card stat-card shadow-sm p-3 mb-2">
                <small class="text-muted fw-bold">ANTREAN PERLU DIPROSES</small>
                <?php $c_pending = mysqli_query($koneksi, "SELECT id_pengajuan FROM pengajuan WHERE status='pending'"); ?>
                <h2 class="fw-bold m-0 text-primary"><?php echo mysqli_num_rows($c_pending); ?> <span class="fs-6 fw-normal text-muted">Data</span></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card stat-card shadow-sm p-3 mb-2 border-start border-danger border-4">
                <small class="text-muted fw-bold text-danger">PERINGATAN STOK MENIPIS</small>
                <?php $c_stok = mysqli_query($koneksi, "SELECT id_produk FROM produk WHERE stok_bal < 10"); ?>
                <h2 class="fw-bold m-0 text-danger"><?php echo mysqli_num_rows($c_stok); ?> <span class="fs-6 fw-normal text-muted">Item</span></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card stat-card shadow-sm p-3 mb-2 border-start border-success border-4">
                <small class="text-muted fw-bold text-success">PENYELESAIAN BULAN INI</small>
                <?php $c_done = mysqli_query($koneksi, "SELECT id_pengajuan FROM pengajuan WHERE status='selesai' AND MONTH(tgl_pengajuan) = MONTH(CURRENT_DATE)"); ?>
                <h2 class="fw-bold m-0 text-success"><?php echo mysqli_num_rows($c_done); ?> <span class="fs-6 fw-normal text-muted">Transaksi</span></h2>
            </div>
        </div>
    </div>

    <div class="card shadow border-0 mb-5">
        <div class="card-header bg-white py-3">
            <strong>Daftar Antrean Pengajuan (Pending)</strong>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Tgl Pengajuan</th>
                            <th>Nama Karyawan</th>
                            <th>Detail Barang (Jumlah)</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $q_pending = mysqli_query($koneksi, "SELECT p.*, u.nama_lengkap FROM pengajuan p JOIN users u ON p.id_karyawan = u.id_user WHERE p.status = 'pending' ORDER BY p.tgl_pengajuan ASC");
                        if(mysqli_num_rows($q_pending) == 0){
                            echo "<tr><td colspan='4' class='text-center text-muted py-4'>Tidak ada pengajuan yang perlu diproses.</td></tr>";
                        }
                        while($row = mysqli_fetch_array($q_pending)){
                            $id_p = $row['id_pengajuan'];
                            $stok_aman = true;
                        ?>
                        <tr>
                            <td><?php echo date('d/m/Y H:i', strtotime($row['tgl_pengajuan'])); ?></td>
                            <td><strong><?php echo $row['nama_lengkap']; ?></strong></td>
                            <td>
                                <ul class="list-unstyled mb-0 small">
                                    <?php 
                                    $q_detail = mysqli_query($koneksi, "SELECT pd.*, pr.nama_rokok, pr.stok_bal FROM pengajuan_detail pd JOIN produk pr ON pd.id_produk = pr.id_produk WHERE pd.id_pengajuan = '$id_p'");
                                    while($det = mysqli_fetch_array($q_detail)){
                                        $peringatan = "";
                                        if($det['jumlah_bal'] > $det['stok_bal']){
                                            $stok_aman = false;
                                            $peringatan = " <span class='stok-peringatan'>(Gudang Hanya Ada: ".$det['stok_bal'].")</span>";
                                        }
                                        echo "<li>• ".$det['nama_rokok']." (".$det['jumlah_bal']." Bal)".$peringatan."</li>";
                                    }
                                    ?>
                                </ul>
                            </td>
                            <td class="text-center">
                                <?php if($stok_aman): ?>
                                    <a href="proses_approval.php?id=<?php echo $id_p; ?>&aksi=setujui" class="btn btn-success btn-sm px-3 shadow-sm">Setujui</a>
                                <?php else: ?>
                                    <button class="btn btn-secondary btn-sm px-3 shadow-sm" disabled>Stok Kurang</button>
                                <?php endif; ?>
                                <button class="btn btn-outline-danger btn-sm px-3" onclick="tolak('<?php echo $id_p; ?>')">Tolak</button>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card shadow border-0 mb-4">
        <div class="card-header bg-dark text-white py-3 d-flex justify-content-between align-items-center">
            <strong>Seluruh Riwayat Keputusan</strong>
            <div class="d-flex gap-2">
                <input type="text" id="cariRiwayat" class="form-control form-control-sm" placeholder="Cari nama/status...">
                <button onclick="eksporExcel()" class="btn btn-success btn-sm d-flex align-items-center gap-1">
                    <span>Excel</span>
                </button>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive table-scroll">
                <table class="table table-sm table-hover mb-0" id="tabelRiwayat">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3 sticky-th">Waktu Keputusan</th>
                            <th class="sticky-th">Nama Karyawan</th>
                            <th class="sticky-th">Status</th>
                            <th class="sticky-th">Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $q_history = mysqli_query($koneksi, "SELECT p.*, u.nama_lengkap FROM pengajuan p JOIN users u ON p.id_karyawan = u.id_user WHERE p.status != 'pending' ORDER BY p.id_pengajuan DESC");
                        while($h = mysqli_fetch_array($q_history)){
                            $badge = ($h['status'] == 'disetujui' || $h['status'] == 'selesai') ? 'bg-success' : 'bg-danger';
                        ?>
                        <tr>
                            <td class="ps-3 small"><?php echo date('d/m/y H:i', strtotime($h['tgl_pengajuan'])); ?></td>
                            <td><strong><?php echo $h['nama_lengkap']; ?></strong></td>
                            <td><span class="badge <?php echo $badge; ?>"><?php echo strtoupper($h['status']); ?></span></td>
                            <td class="small text-muted italic"><?php echo $h['alasan_tolak'] ?? '-'; ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white small text-muted">
            Menampilkan <?php echo mysqli_num_rows($q_history); ?> total transaksi.
        </div>
    </div>
</div>

<script>
// Fungsi Ekspor ke Excel
function eksporExcel() {
    var table = document.getElementById("tabelRiwayat");
    var wb = XLSX.utils.table_to_book(table, {sheet: "Riwayat Transaksi"});
    XLSX.writeFile(wb, "Laporan_Persetujuan_Inventory.xlsx");
}

// Fungsi Penolakan
function tolak(id) {
    let alasan = prompt("Masukkan alasan penolakan:");
    if (alasan != null && alasan != "") {
        window.location.href = "proses_approval.php?id=" + id + "&aksi=tolak&alasan=" + alasan;
    }
}

// Pencarian Real-time
document.getElementById('cariRiwayat').addEventListener('keyup', function() {
    let filter = this.value.toLowerCase();
    let rows = document.querySelector('#tabelRiwayat tbody').rows;
    for (let i = 0; i < rows.length; i++) {
        let text = rows[i].innerText.toLowerCase();
        rows[i].style.display = text.includes(filter) ? "" : "none";
    }
});
</script>

</body>
</html>