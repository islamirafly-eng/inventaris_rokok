<?php
session_start();
include '../config/koneksi.php';

// KODE PENGAMAN: Hanya Atasan yang bisa memproses
if($_SESSION['role'] != "atasan"){ 
    header("location:../index.php?pesan=bukan_atasan");
    exit(); 
}

$id_p   = $_GET['id'];
$aksi   = $_GET['aksi'];
$id_bos = $_SESSION['id_user'];

if($aksi == "setujui"){
    // --- VALIDASI STOK FINAL (Mencegah stok minus saat klik berbarengan) ---
    $cek_stok = mysqli_query($koneksi, "SELECT pd.jumlah_bal, pr.stok_bal, pr.nama_rokok 
                                        FROM pengajuan_detail pd 
                                        JOIN produk pr ON pd.id_produk = pr.id_produk 
                                        WHERE pd.id_pengajuan = '$id_p'");
    
    while($s = mysqli_fetch_array($cek_stok)){
        if($s['jumlah_bal'] > $s['stok_bal']){
            // Jika stok tiba-tiba tidak cukup, lempar balik ke dashboard dengan pesan error
            header("location:dashboard.php?pesan=gagal_stok&barang=" . urlencode($s['nama_rokok']));
            exit();
        }
    }

    // Jika stok aman, update status menjadi disetujui
    mysqli_query($koneksi, "UPDATE pengajuan SET 
                            status='disetujui', 
                            id_atasan='$id_bos' 
                            WHERE id_pengajuan='$id_p'");

} else if($aksi == "tolak"){
    // Ambil alasan dan amankan dari karakter aneh/simbol
    $alasan = isset($_GET['alasan']) ? mysqli_real_escape_string($koneksi, $_GET['alasan']) : "Ditolak tanpa alasan";
    
    // Update status menjadi ditolak dan simpan alasannya ke kolom alasan_tolak
    mysqli_query($koneksi, "UPDATE pengajuan SET 
                            status='ditolak', 
                            id_atasan='$id_bos', 
                            alasan_tolak='$alasan' 
                            WHERE id_pengajuan='$id_p'");
}



header("location:dashboard.php?pesan=berhasil_proses");
?>

<?php if(isset($_GET['pesan']) && $_GET['pesan'] == 'gagal_stok'): ?>
    <div class="alert alert-danger alert-dismissible fade show mx-3 shadow-sm" role="alert">
        <strong>Persetujuan Dibatalkan!</strong> Stok barang <b><?php echo $_GET['barang']; ?></b> sudah tidak mencukupi untuk memenuhi pengajuan ini.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>