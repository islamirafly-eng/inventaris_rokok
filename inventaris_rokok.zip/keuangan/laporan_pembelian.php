<?php 
session_start();
if($_SESSION['role'] != "keuangan"){
    header("location:../index.php?pesan=bukan_keuangan");
    exit();
}
include '../config/koneksi.php';

// Menangkap filter tanggal
$tgl_mulai = isset($_GET['tgl_mulai']) ? $_GET['tgl_mulai'] : '';
$tgl_selesai = isset($_GET['tgl_selesai']) ? $_GET['tgl_selesai'] : '';

// LOGIKA EKSPOR EXCEL (Harus diletakkan sebelum tag HTML apapun)
if(isset($_GET['ekspor']) && $_GET['ekspor'] == 'excel'){
    header("Content-type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=Laporan_Pembelian_" . date('d-m-Y') . ".xls");
    // Saat ekspor excel, kita menggunakan layout tabel yang lebih sederhana
    $is_excel = true;
} else {
    $is_excel = false;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Lengkap Pembelian</title>
    <?php if(!$is_excel): ?>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        .card { border-radius: 12px; }
        .table-footer-total { background-color: #f8f9fa; font-weight: bold; }
        @media print {
            .no-print { display: none !important; }
            .card { border: none !important; box-shadow: none !important; }
            body { background-color: white !important; }
        }
    </style>
    <?php endif; ?>
</head>
<body class="<?= !$is_excel ? 'bg-light' : '' ?>">

<div class="<?= !$is_excel ? 'container mt-5 mb-5' : '' ?>">
    
    <?php if(!$is_excel): ?>
    <div class="d-flex justify-content-between align-items-center mb-4 no-print">
        <a href="dashboard.php" class="btn btn-secondary shadow-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
        <div>
            <a href="?tgl_mulai=<?= $tgl_mulai ?>&tgl_selesai=<?= $tgl_selesai ?>&ekspor=excel" class="btn btn-success shadow-sm me-2">
                <i class="bi bi-file-earmark-excel me-1"></i> Ekspor Excel
            </a>
            <button onclick="window.print()" class="btn btn-dark shadow-sm">
                <i class="bi bi-printer me-1"></i> Cetak Laporan
            </button>
        </div>
    </div>

    <div class="card shadow-sm mb-4 no-print border-0">
        <div class="card-body">
            <h6 class="fw-bold mb-3 text-primary"><i class="bi bi-funnel me-1"></i> Filter Laporan</h6>
            <form action="" method="GET" class="row g-2">
                <div class="col-md-4">
                    <input type="date" name="tgl_mulai" class="form-control" value="<?php echo $tgl_mulai; ?>" required>
                    <small class="text-muted">Tanggal Mulai</small>
                </div>
                <div class="col-md-4">
                    <input type="date" name="tgl_selesai" class="form-control" value="<?php echo $tgl_selesai; ?>" required>
                    <small class="text-muted">Tanggal Selesai</small>
                </div>
                <div class="col-md-4 d-flex align-items-start">
                    <button type="submit" class="btn btn-primary w-100 fw-bold">Tampilkan</button>
                    <?php if($tgl_mulai != ''): ?>
                        <a href="laporan_pembelian.php" class="btn btn-outline-danger ms-2"><i class="bi bi-x-circle"></i></a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <div class="<?= !$is_excel ? 'card shadow-sm' : '' ?>">
        <?php if(!$is_excel): ?>
        <div class="card-header bg-primary text-white text-center py-3">
            <h5 class="m-0 fw-bold text-uppercase">Ringkasan Riwayat Pembelian</h5>
            <?php if($tgl_mulai && $tgl_selesai): ?>
                <small>Periode: <?php echo date('d/m/Y', strtotime($tgl_mulai)); ?> - <?php echo date('d/m/Y', strtotime($tgl_selesai)); ?></small>
            <?php endif; ?>
        </div>
        <?php else: ?>
            <h2 style="text-align:center;">LAPORAN PEMBELIAN BARANG</h2>
            <p>Periode: <?= $tgl_mulai ?> s/d <?= $tgl_selesai ?></p>
        <?php endif; ?>

        <div class="<?= !$is_excel ? 'card-body p-0' : '' ?>">
            <div class="table-responsive">
                <table class="table <?= !$is_excel ? 'table-striped table-hover mb-0 align-middle' : '' ?>" border="1">
                    <thead class="<?= !$is_excel ? 'table-dark' : '' ?>">
                        <tr>
                            <th width="5%" style="text-align:center;">No</th>
                            <th>Tanggal & Waktu</th>
                            <th>Nama Produk</th>
                            <th style="text-align:center;">Jumlah (Bal)</th>
                            <th style="text-align:center;">Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        $total_akumulasi = 0;
                        $sql = "SELECT b.*, p.nama_rokok FROM pembelian b JOIN produk p ON b.id_produk = p.id_produk";
                        
                        if($tgl_mulai && $tgl_selesai) {
                            $sql .= " WHERE DATE(b.tgl_beli) BETWEEN '$tgl_mulai' AND '$tgl_selesai'";
                        }
                        
                        $sql .= " ORDER BY b.tgl_beli DESC";
                        $query = mysqli_query($koneksi, $sql);

                        if(mysqli_num_rows($query) == 0) {
                            echo "<tr><td colspan='5' style='text-align:center;'>Data tidak ditemukan.</td></tr>";
                        }

                        while($d = mysqli_fetch_array($query)){
                            $total_akumulasi += $d['jumlah_beli'];
                        ?>
                        <tr>
                            <td style="text-align:center;"><?php echo $no++; ?></td>
                            <td><?php echo date('d/m/Y H:i', strtotime($d['tgl_beli'])); ?> WIB</td>
                            <td style="font-weight:bold;"><?php echo $d['nama_rokok']; ?></td>
                            <td style="text-align:center;">+ <?php echo $d['jumlah_beli']; ?></td>
                            <td style="text-align:center;">Finance Verified</td>
                        </tr>
                        <?php } ?>
                    </tbody>
                    <?php if(mysqli_num_rows($query) > 0): ?>
                    <tfoot class="table-footer-total">
                        <tr style="background-color: #eee; font-weight:bold;">
                            <td colspan="3" style="text-align:right; padding: 10px;">TOTAL KESELURUHAN :</td>
                            <td style="text-align:center; color:blue;"><?php echo $total_akumulasi; ?> BAL</td>
                            <td></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
    
    <?php if(!$is_excel): ?>
    <p class="text-center mt-3 text-muted small">Dicetak pada: <?php echo date('d/m/Y H:i'); ?> WIB</p>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <?php endif; ?>
</div>

</body>
</html>