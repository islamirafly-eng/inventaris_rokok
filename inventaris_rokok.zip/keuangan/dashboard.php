<?php 
session_start();
if($_SESSION['role'] != "keuangan"){
    header("location:../index.php?pesan=bukan_keuangan");
    exit();
}
include '../config/koneksi.php';

$total_produk = mysqli_num_rows(mysqli_query($koneksi, "SELECT id_produk FROM produk"));
$stok_kritis  = mysqli_num_rows(mysqli_query($koneksi, "SELECT id_produk FROM produk WHERE stok_bal < 10"));
$beli_bulan_ini = mysqli_fetch_array(mysqli_query($koneksi, "SELECT SUM(jumlah_beli) as total FROM pembelian WHERE MONTH(tgl_beli) = MONTH(CURRENT_DATE())"));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Keuangan - Inventory System</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        :root { --primary-dark: #1a1a1a; }
        body { background-color: #f4f7f6; font-family: 'Inter', sans-serif; }
        .navbar { background-color: var(--primary-dark) !important; }
        .card { border-radius: 12px; border: none; }
        .stat-card { border-left: 4px solid #0d6efd; }
        .stat-card.danger { border-left-color: #dc3545; }
        .stat-card.success { border-left-color: #198754; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="dashboard.php"><i class="bi bi-wallet2 me-2"></i> FINANCE PANEL</a>
        <div class="d-flex align-items-center">
            <span class="text-light me-3 small">Halo, <strong><?php echo $_SESSION['nama']; ?></strong></span>
            <a href="../auth/logout.php" class="btn btn-danger btn-sm px-3 shadow-sm"><i class="bi bi-power"></i> Keluar</a>
        </div>
    </div>
</nav>

<div class="container">
    <?php if(isset($_GET['pesan']) && $_GET['pesan'] == 'berhasil'): ?>
        <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show" role="alert">
            <strong>Berhasil!</strong> Stok gudang telah diperbarui.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card shadow-sm stat-card p-3 mb-2">
                <small class="text-muted fw-bold text-uppercase">Total Item Produk</small>
                <h3 class="fw-bold m-0"><?php echo $total_produk; ?> <span class="fs-6 fw-normal text-muted">Merk</span></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm stat-card danger p-3 mb-2">
                <small class="text-muted fw-bold text-uppercase">Stok Kritis</small>
                <h3 class="fw-bold m-0 text-danger"><?php echo $stok_kritis; ?> <span class="fs-6 fw-normal text-muted">Perlu Restock</span></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm stat-card success p-3 mb-2">
                <small class="text-muted fw-bold text-uppercase">Pembelian Bulan Ini</small>
                <h3 class="fw-bold m-0 text-success">+<?php echo $beli_bulan_ini['total'] ?? 0; ?> <span class="fs-6 fw-normal text-muted">Bal Masuk</span></h3>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white py-3 fw-bold border-bottom">
                    <i class="bi bi-plus-circle me-2 text-primary"></i> Update Stok (Beli)
                </div>
                <div class="card-body">
                    <form action="proses_beli.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Pilih Barang</label>
                            <select name="id_produk" class="form-select border-0 bg-light" required>
                                <option value="">-- Pilih Rokok --</option>
                                <?php 
                                $produk = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY nama_rokok ASC");
                                while($p = mysqli_fetch_array($produk)){
                                    echo "<option value='".$p['id_produk']."'>".$p['nama_rokok']." (Sisa: ".$p['stok_bal'].")</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Jumlah Beli (Bal)</label>
                            <input type="number" name="jumlah" class="form-control border-0 bg-light" min="1" required placeholder="Contoh: 50">
                        </div>
                        <button type="submit" class="btn btn-primary w-100 fw-bold py-2 shadow-sm">SIMPAN PEMBELIAN</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-dark text-white py-3 d-flex justify-content-between align-items-center">
                    <span class="fw-bold small text-uppercase"><i class="bi bi-clock-history me-2"></i> 10 Transaksi Terakhir</span>
                    <a href="laporan_pembelian.php" class="btn btn-outline-light btn-sm px-3">Lihat Semua</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr class="small">
                                    <th class="ps-4">Tanggal</th>
                                    <th>Produk</th>
                                    <th class="text-center">Jumlah</th>
                                    <th class="text-end pe-4">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $q_beli = mysqli_query($koneksi, "SELECT b.*, p.nama_rokok FROM pembelian b 
                                          JOIN produk p ON b.id_produk = p.id_produk ORDER BY b.id_pembelian DESC LIMIT 10");
                                while($r = mysqli_fetch_array($q_beli)){
                                ?>
                                <tr>
                                    <td class="ps-4 small text-muted"><?php echo date('d/m/y H:i', strtotime($r['tgl_beli'])); ?></td>
                                    <td class="fw-bold"><?php echo $r['nama_rokok']; ?></td>
                                    <td class="text-center"><span class="badge bg-success-subtle text-success border border-success">+ <?php echo $r['jumlah_beli']; ?> Bal</span></td>
                                    <td class="text-end pe-4 text-primary small"><i class="bi bi-check-all"></i> Selesai</td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>