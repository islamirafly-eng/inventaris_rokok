<?php 
session_start();
if($_SESSION['role'] != "keuangan"){
    header("location:../index.php?pesan=bukan_keuangan");
    exit();
}
include '../config/koneksi.php';

// Proses Update Pengaturan
if(isset($_POST['update'])){
    $wa = $_POST['nomor_wa'];
    $batas = $_POST['batas_minimum'];
    $token = $_POST['api_token'];
    $status = $_POST['status_notif'];

    $update = mysqli_query($koneksi, "UPDATE setting_notif SET 
                nomor_wa='$wa', 
                batas_minimum='$batas', 
                api_token='$token', 
                status_notif='$status' 
                WHERE id=1");
    if($update) { $pesan = "update_berhasil"; }
}

// Ambil data pengaturan saat ini
$data = mysqli_fetch_array(mysqli_query($koneksi, "SELECT * FROM setting_notif WHERE id=1"));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pengaturan Notifikasi WA</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <a href="dashboard.php" class="btn btn-secondary mb-3"><i class="bi bi-arrow-left"></i> Kembali</a>
            
            <?php if(isset($pesan)): ?>
                <div class="alert alert-success">Pengaturan berhasil diperbarui!</div>
            <?php endif; ?>

            <div class="card shadow-sm border-0">
                <div class="card-header bg-dark text-white py-3">
                    <h5 class="mb-0"><i class="bi bi-whatsapp me-2"></i>Konfigurasi WhatsApp Gateway</h5>
                </div>
                <div class="card-body">
                    <form action="" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nomor WhatsApp Penerima</label>
                            <input type="text" name="nomor_wa" class="form-control" value="<?= $data['nomor_wa'] ?>" placeholder="Contoh: 08123456789">
                            <small class="text-muted">Gunakan format angka langsung (08...)</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Batas Minimum Stok (Bal)</label>
                            <input type="number" name="batas_minimum" class="form-control" value="<?= $data['batas_minimum'] ?>">
                            <small class="text-muted">Notifikasi dikirim jika stok sama dengan atau di bawah angka ini.</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Fonnte API Token</label>
                            <input type="password" name="api_token" class="form-control" value="<?= $data['api_token'] ?>">
                            <small class="text-muted">Dapatkan token di dashboard fonnte.com</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Status Notifikasi</label>
                            <select name="status_notif" class="form-select">
                                <option value="aktif" <?= $data['status_notif'] == 'aktif' ? 'selected' : '' ?>>Aktif</option>
                                <option value="nonaktif" <?= $data['status_notif'] == 'nonaktif' ? 'selected' : '' ?>>Nonaktif (Mati)</option>
                            </select>
                        </div>
                        <button type="submit" name="update" class="btn btn-primary w-100 fw-bold">Simpan Pengaturan</button>
                    </form>
                </div>
            </div>
            
            <div class="alert alert-info mt-4 small">
                <i class="bi bi-info-circle-fill"></i> <strong>Cara Kerja:</strong> Sistem akan otomatis mengirim pesan WA ketika karyawan menginput barang keluar dan sisa stok mencapai batas minimum yang Anda tentukan.
            </div>
        </div>
    </div>
</div>
</body>
</html>