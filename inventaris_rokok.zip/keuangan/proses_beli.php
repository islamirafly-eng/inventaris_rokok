<?php
session_start();
include '../config/koneksi.php';

if($_SESSION['role'] != "keuangan"){ exit(); }

$id_produk   = $_POST['id_produk'];
$jumlah      = $_POST['jumlah'];
$id_keuangan = $_SESSION['id_user']; // Mengambil ID user yang sedang login

// 1. Tambahkan jumlah stok ke tabel produk
mysqli_query($koneksi, "UPDATE produk SET stok_bal = stok_bal + $jumlah WHERE id_produk = '$id_produk'");

// 2. CATAT RIWAYAT: Masukkan data ke tabel pembelian agar tanggalnya muncul
$query_beli = "INSERT INTO pembelian (id_produk, id_keuangan, jumlah_beli) 
               VALUES ('$id_produk', '$id_keuangan', '$jumlah')";

if(mysqli_query($koneksi, $query_beli)){
    header("location:dashboard.php?pesan=stok_bertambah");
} else {
    echo "Gagal mencatat riwayat: " . mysqli_error($koneksi);
}
?>